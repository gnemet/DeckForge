#!/bin/bash
./slideforge
